package com.ibrahim.ichat;

public class NotificationActivity
{
}