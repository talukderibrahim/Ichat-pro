package com.ibrahim.ichat;

public class UserAdapter
{
}