package com.ibrahim.ichat;

public class GroupSettingsActivity
{
}