package com.ibrahim.ichat;

public class SplashActivity
{
}